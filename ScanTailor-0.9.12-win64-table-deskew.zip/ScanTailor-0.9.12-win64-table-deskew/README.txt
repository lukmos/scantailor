Scan Tailor 0.9.12 for 64-bit Windows
Extract the entire ZIP, then open scantailor.exe.
Use scantailor-cli.exe --help for command-line options.
Deskew uses repeated table boundaries when they agree, with CNN text detection as fallback.
Source project: https://github.com/lukmos/scantailor
Built with the MXE cross environment and Qt 4.8.7.
Build source commit: f6f1f66
Build source is included in source/scantailor-source.tar.gz.
Qt source: https://download.qt.io/archive/qt/4.8/4.8.7/
