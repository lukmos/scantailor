Scan Tailor 0.9.12 for 64-bit Windows
Extract the entire ZIP, then open scantailor.exe.
Use scantailor-cli.exe --help for command-line options.
Deskew uses an 8:1 center-to-edge weight ratio.
Source project: https://github.com/lukmos/scantailor
Built with the MXE cross environment and Qt 4.8.7.
The exact Scan Tailor source used for this build is included in source/scantailor-source.tar.gz.
Qt source: https://download.qt.io/archive/qt/4.8/4.8.7/
Cross toolchain and library recipes: https://mxe.cc/
